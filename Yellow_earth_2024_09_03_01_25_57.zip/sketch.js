let xBolinha = 300;
let yBolinha = 200;
let diametro = 20;
let raio = diametro / 2;

// Velocidade da bolinha
let velocidadeXBolinha = 6;
let velocidadeYBolinha = 6;

// Variáveis da raquete do jogador
let xRaqueteJogador = 10;
let yRaqueteJogador = 150;
let raqueteComprimento = 10;
let raqueteAltura = 90;

// Variáveis da raquete da IA
let xRaqueteIA = 580;
let yRaqueteIA = 150;
let velocidadeYRaqueteIA = 5;

// Pontuação
let pontuacaoJogador = 0;
let pontuacaoIA = 0;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  
  // Mostra as raquetes e a bolinha
  mostraBolinha();
  mostraRaqueteJogador();
  mostraRaqueteIA();
  
  // Move a bolinha
  movimentaBolinha();
  
  // Verifica colisões
  verificaColisaoBorda();
  verificaColisaoRaqueteJogador();
  verificaColisaoRaqueteIA();
  
  // Move a raquete do jogador
  movimentaRaqueteJogador();
  
  // Move a raquete da IA
  movimentaRaqueteIA();
  
  // Mostra a pontuação
  mostraPontuacao();
}

function mostraBolinha() {
  fill(255);
  circle(xBolinha, yBolinha, diametro);
}

function movimentaBolinha() {
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}

function verificaColisaoBorda() {
  // Colisão com a borda superior e inferior
  if (yBolinha + raio > height || yBolinha - raio < 0) {
    velocidadeYBolinha *= -1;
  }
  
  // Colisão com a borda esquerda (marcando ponto para a IA) 
  if (xBolinha - raio < 0) {
    pontuacaoIA++;
    resetarBolinha();
  }
  
  // Colisão com a borda direita (marcando ponto para o jogador)
  if (xBolinha + raio > width) {
    pontuacaoJogador++;
    resetarBolinha();
  }
}

function verificaColisaoRaqueteJogador() {
  if (xBolinha - raio < xRaqueteJogador + raqueteComprimento &&
      yBolinha > yRaqueteJogador &&
      yBolinha < yRaqueteJogador + raqueteAltura) {
    velocidadeXBolinha *= -1;
  }
}

function verificaColisaoRaqueteIA() {
  if (xBolinha + raio > xRaqueteIA &&
      yBolinha > yRaqueteIA &&
      yBolinha < yRaqueteIA + raqueteAltura) {
    velocidadeXBolinha *= -1;
  }
}

function movimentaRaqueteJogador() {
  if (keyIsDown(UP_ARROW)) {
    yRaqueteJogador -= 10;
  }
  if (keyIsDown(DOWN_ARROW)) {
    yRaqueteJogador += 10;
  }
  
  // Limita a raquete do jogador ao canvas
  yRaqueteJogador = constrain(yRaqueteJogador, 0, height - raqueteAltura);
}

function movimentaRaqueteIA() {
  if (yRaqueteIA + raqueteAltura / 2 < yBolinha) {
    yRaqueteIA += velocidadeYRaqueteIA;
  } else {
    yRaqueteIA -= velocidadeYRaqueteIA;
  }
  
  // Limita a raquete da IA ao canvas
  yRaqueteIA = constrain(yRaqueteIA, 0, height - raqueteAltura);
}

function mostraRaqueteJogador() {
  fill(255);
  rect(xRaqueteJogador, yRaqueteJogador, raqueteComprimento, raqueteAltura);
}

function mostraRaqueteIA() {
  fill(255);
  rect(xRaqueteIA, yRaqueteIA, raqueteComprimento, raqueteAltura);
}

function mostraPontuacao() {
  textSize(32);
  fill(255);
  textAlign(CENTER, TOP);
  text(pontuacaoJogador, width / 4, 20);
  text(pontuacaoIA, 3 * width / 4, 20);
}

function resetarBolinha() {
  xBolinha = width / 2;
  yBolinha = height / 2;
  velocidadeXBolinha *= -1;
}
